# Dot Matrix Tool

A web application for generating character or image byte arrays for dot matrix style OLED or LCD displays.

Use it live at http://dotmatrixtool.com

Blog post at http://www.stefangordon.com/build-icons-and-characters-for-monochrome-lcd-matrix-displays/
